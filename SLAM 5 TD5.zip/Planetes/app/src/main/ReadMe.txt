Ce dossier contient un projet Android API 17 qui affiche une liste de planètes.

L'icône d'application a été téléchargé sur le site http://icones.pro qu'on ne peut que recommander.



